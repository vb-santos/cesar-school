#include <stdio.h>
 
int main() {
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);

    int X = a + b;

    printf("X = %d\n", X);

    return 0;
}