// #include<stdio.h>

int main(){
    printf ("Inteiro = %d, Real = %g, Double = %.2f\n", 33, 5.3, 3.9087);
    return 0;
}