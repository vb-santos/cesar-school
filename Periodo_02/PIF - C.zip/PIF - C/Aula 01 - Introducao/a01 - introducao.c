int main(){
    char d;
    float f;

    int x = 234;
    double m = 10.3, n = 11.145;

    d = 'd';
    f = 32.5;

    return 0;
}