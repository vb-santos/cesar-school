#ifndef OPERACOES_H
#define OPERACOES_H

int soma(int a, int b);

#endif