#include <stdio.h>

int main(void) {

  int numA, numB;

  scanf("%d", &numA);
  scanf("%d", &numB);

  printf("%d\n", numA % numB);
}