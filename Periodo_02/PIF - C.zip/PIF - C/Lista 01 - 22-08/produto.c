#include <stdio.h>

int main(void) {
    int numA, numB, PROD;

    scanf("%d", &numA);
    scanf("%d", &numB);

    PROD = numA * numB;

    printf("PROD = %d\n", PROD);
}