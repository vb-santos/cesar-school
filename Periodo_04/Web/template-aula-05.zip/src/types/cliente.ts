export type Cliente = {
  id: number;
  nome: string;
  email: string;
  ativo: boolean;
  criadoEm: string;
};
